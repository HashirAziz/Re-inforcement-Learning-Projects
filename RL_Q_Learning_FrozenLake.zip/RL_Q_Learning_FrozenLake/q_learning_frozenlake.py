# q_learning_frozenlake.py
import gym
import numpy as np
import random

# --- Initialize Environment ---
env = gym.make("FrozenLake-v1", is_slippery=True)  # stochastic (slippery)
n_states = env.observation_space.n   # 16
n_actions = env.action_space.n       # 4

# --- Hyperparameters ---
EPSILON = 0.3      # exploration rate
ALPHA = 0.3        # learning rate
GAMMA = 0.99       # discount factor
EPISODES = 10000   # number of training episodes

# --- Q-table Initialization ---
Q = np.zeros((n_states, n_actions))

# --- Choose Action (ε-greedy) ---
def choose_action(state):
    if random.uniform(0, 1) < EPSILON:
        return env.action_space.sample()  # Explore: random action
    else:
        return np.argmax(Q[state, :])     # Exploit: best known action

# --- Update Q-table (Q-Learning Rule) ---
def update_q_table(state, action, reward, next_state, done):
    best_next = np.max(Q[next_state, :])  # max over all actions in next state
    Q[state, action] += ALPHA * (reward + GAMMA * best_next * (not done) - Q[state, action])

# --- Training Loop ---
def train_agent():
    rewards_per_episode = []
    for episode in range(EPISODES):
        state, _ = env.reset()
        done = False
        total_reward = 0

        while not done:
            action = choose_action(state)
            next_state, reward, done, truncated, info = env.step(action)
            update_q_table(state, action, reward, next_state, done)
            state = next_state
            total_reward += reward

        rewards_per_episode.append(total_reward)

        # Print progress
        if episode % 500 == 0 or episode == 1:
            avg_reward = np.mean(rewards_per_episode[-100:])
            print(f"Episode {episode:5d} | Reward: {total_reward:.2f} | "
                  f"Avg(100): {avg_reward:.3f} | Epsilon: {EPSILON:.3f}")

    return Q, rewards_per_episode

# --- Evaluation Function ---
def evaluate_agent(episodes=100):
    total_rewards = 0
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        while not done:
            action = np.argmax(Q[state, :])  # Greedy: best action
            state, reward, done, truncated, info = env.step(action)
            total_rewards += reward
    avg_reward = total_rewards / episodes
    print(f"\nAverage reward over {episodes} evaluation episodes: {avg_reward:.2f}")
    return avg_reward

# ========================== RUN TRAINING ==========================
print("Starting Q-Learning on FrozenLake-v1 (slippery)...")
Q, rewards = train_agent()

print("\nLearned Q-table (Q-Learning):")
print(np.round(Q, 3))

evaluate_agent()