# sarsa_frozenlake.py
import gym
import numpy as np
import random

# --- Initialize Environment ---
env = gym.make("FrozenLake-v1", is_slippery=True)
n_states = env.observation_space.n
n_actions = env.action_space.n

# --- Hyperparameters ---
EPSILON = 0.3      # exploration rate
ALPHA = 0.3        # learning rate
GAMMA = 0.99       # discount factor
EPISODES = 10000

# --- Q-table Initialization ---
Q = np.zeros((n_states, n_actions))

# --- Choose Action (ε-greedy) ---
def choose_action(state):
    if random.uniform(0, 1) < EPSILON:
        return env.action_space.sample()  # Explore
    else:
        return np.argmax(Q[state, :])     # Exploit

# --- SARSA Update ---
def update_q_table(state, action, reward, next_state, next_action, done):
    target = reward + GAMMA * Q[next_state, next_action] * (not done)
    Q[state, action] += ALPHA * (target - Q[state, action])

# --- Training Loop ---
def train_agent():
    rewards_per_episode = []
    for episode in range(EPISODES):
        state, _ = env.reset()
        action = choose_action(state)  # First action
        done = False
        total_reward = 0

        while not done:
            next_state, reward, done, truncated, _ = env.step(action)
            next_action = choose_action(next_state)  # Action for next state
            update_q_table(state, action, reward, next_state, next_action, done)

            state = next_state
            action = next_action
            total_reward += reward

        rewards_per_episode.append(total_reward)

        # Print progress
        if episode % 500 == 0 or episode == 1:
            avg_reward = np.mean(rewards_per_episode[-100:])
            print(f"Episode {episode:5d} | Reward: {total_reward:.2f} | "
                  f"Avg(100): {avg_reward:.3f} | Epsilon: {EPSILON:.3f}")

    return Q, rewards_per_episode

# --- Evaluation ---
def evaluate_agent(episodes=100):
    total_rewards = 0
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        while not done:
            action = np.argmax(Q[state, :])
            state, reward, done, truncated, _ = env.step(action)
            total_rewards += reward
    avg_reward = total_rewards / episodes
    print(f"\nAverage reward over {episodes} evaluation episodes: {avg_reward:.2f}")
    return avg_reward

# --- RUN TRAINING ---
print("Starting SARSA training on FrozenLake-v1...")
Q, rewards = train_agent()

print("\nLearned Q-table (SARSA):")
print(np.round(Q, 3))

evaluate_agent()